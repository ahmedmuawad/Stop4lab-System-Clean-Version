<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCommentComponetsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('comment_componets', function (Blueprint $table) {
            $table->id();
            $table->integer('test_id');
            $table->integer('comment_id');
            $table->integer('component_id');
            $table->integer('condition_id')->nullable();
            $table->enum('operation_condition_type', ['or', 'and'])->default("or");
            $table->enum('condition_values_type', ['or', 'and'])->default("or");
            $table->text("values")->nullable();
            $table->enum('operation_values_type', ['or', 'and'])->default("or");
            $table->enum('above_op_type', ['or', 'and'])->nullable()->default('or');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('comment_componets');
    }
}
