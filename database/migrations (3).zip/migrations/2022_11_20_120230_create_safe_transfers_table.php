<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSafeTransfersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('safe_transfers', function (Blueprint $table) {
            $table->id();
            $table->integer('from_branch_id');
            $table->integer('from_user_id');
            $table->integer('to_branch_id');
            $table->integer('to_user_id')->nullable();
            $table->date('from_date');
            $table->date('to_date');
            $table->enum('export',['Pending','Accept','Refused','Send'])->default('Pending');
            $table->enum('accept',['Pending','Accept','Refused'])->default('Pending');
            $table->enum('type',['Inside','Outside'])->default('Inside');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('safe_transfers');
    }
}
