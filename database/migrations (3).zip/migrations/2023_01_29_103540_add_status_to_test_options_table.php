<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddStatusToTestOptionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('test_options', function (Blueprint $table) {
            $table->string('status')->default('Abnormal')->nullable();
            $table->string('gender')->default('both')->nullable();
        });
        Schema::table('test_option_additional', function (Blueprint $table) {
            $table->string('status')->default('Abnormal')->nullable();
            $table->string('gender')->default('both')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('test_options', function (Blueprint $table) {
            //
        });
    }
}
