
@extends('layouts.app')

@section('title')
    {{__('Comments')}}
@endsection
@section('breadcrumb')
          <li class="breadcrumb-item"><a href="{{route('admin.index')}}">{{__('Home')}}</a></li>
          <li class="breadcrumb-item active">{{__('Details')}}</li>
@endsection

@section('content')
<div class="app-content content ">
<div class="card card-primary card-outline">
    <div class="card-header">
      <h3 class="card-title">
        {{__('Comment Details')}}
      </h3>
      
    </div>
    <!-- /.card-header -->
  
    <div class="card-body">
       <div class="col-lg-12 table-responsive">
          <table class="table table table-striped table-bordered"  width="100%">
            <thead>
            <tr>
              <th width="10px">
                <input type="checkbox" class="check_all" name="" id="">
              </th>
              <th width="10px">#</th>
              <th>{{__('condition')}}</th>
            </tr>
            </thead>
            <tbody>
                @foreach($comment as $details)
                     @if($details->above_op_type!=null)
                        <tr> 
                            <td colspan="3" align="center">
                                {{$details->above_op_type}}
                            </td> 
                        </tr>            
                    @endif
                    <tr>
                        <td></td>
                        <td>{{ $loop->index }}</td>
                        <td>
                           
                            {{__('IF ')}} {{$details->test->name}} Normal Range is {{config('conditions')[$details->condition_id]['name']}} {{$details->operation_condition_type}} 
                            @if(isset($details->operationComments) && isset($details->operationComments->operation)) Results are 
                                    {{$details->operationComments->operation->name}}
                                    {{$details->operationComments->value1}}
                                
                                @if($details->operationComments->value2!=null)
                                    -
                                    {{$details->operationComments->value2}}
                                @endif              
                            @endif
                            
                            @if($details->values!=null)
                            {{$details->condition_values_type}} Resualt are equal {{$details->values}} As A String
                            @endif
                            
                        </td>
                    </tr>
                @endforeach
            </tbody>
          </table>
       </div>
    </div>
    <!-- /.card-body -->
  </div>
</div>
@endsection
@section('scripts')
  <script src="{{url('js/admin/comment.js')}}"></script>
@endsection
<script>
  var can_delete=@can('delete_hr')true @else false @endcan
</script>


