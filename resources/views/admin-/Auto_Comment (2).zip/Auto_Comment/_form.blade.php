<div class="" id="comments">
    @if(isset($comment))
        @foreach($comment as $com)
    <div class="coment-row" data-row="{{$loop->index}}">
        @if($loop->index!=0)
        <hr/>
        <div class="col-lg-12">
            <div class="form-group">
                <label class="form-label"
                     for="Values">{{__('above_op_type')}}</label>
                <select class="form-control" name="comments[{{$loop->index}}][above_op_type]">
                    <option  value='or'
                    {{ $com->above_op_type == 'or' ? 'selected' : '' }}
                    >
                        {{__('OR')}}
                    </option>
                    <option value='and'
                    {{ $com->above_op_type == 'and' ? 'selected' : '' }}
                    
                    >
                        {{__('and')}}
                    </option>
                </select>
            </div>
        </div>
        <hr/>
        @endif
        <div class="row">
            <div class="col-lg-4 testSelect">
                <div class="form-group">
                    <label class="form-label" for="test">{{ __('Test Name') }}</label>
                    <select id="test" class="form-control" name="comments[{{$loop->index}}][test_id][]">
                        @foreach ($test->components as $component)
                            <option 
                            @if(isset($com))
                                {{ $component->id == $com->component_id ? 'selected' : '' }}
                            @endif
                            class="text-center" value="{{ $component->id }}">
                                {{ $component->name }}
                            </option>
                        @endforeach
                    </select>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="form-group">
                    <label class="form-label" for="operation">{{ __('Opertion Name') }}</label>
                    <select  class="opertionSelect form-control" name="comments[{{$loop->index}}][operations][id]">
                        <option class="text-center" selected>
                            __
                        </option>
                        @foreach ($operations as $operation)
                            <option data-operands="{{ $operation->operands }}" class="text-center"
                                value="{{ $operation->id }}"
                                @if(isset($com))
                                    {{ $operation->id == $com->operationComments->operation_id ? 'selected' : '' }}
                                @endif
                                >
                                {{ __($operation->name) }}
                            </option>
                        @endforeach
                    </select>
                </div>
            </div>
            @if(isset($com->operationComments))
            <div class="col-lg-4 values">
                <label value="" id="value_1">value_1</label>
                <input class="form-control" value="{{$com->operationComments->value1}}" type="number" name="comments[{{$loop->index}}][operations][values][]">
            </div>

            @if($com->operationComments->value2!=null)
                <div class="col-lg-4 values">
                    <label value="" id="value_2">value_2</label>
                    <input class="form-control" value="{{$com->operationComments->value2}}" type="number" name="comments[{{$loop->index}}][operations][values][]">
                </div>
            @endif

            @endif
            <div class="col-lg-4">
                <div class="form-group">
                    <label class="form-label" for="condition">{{ __('condition') }}</label>
                    <select class="form-control" name="comments[{{$loop->index}}][condition]">
                        <option class="text-center" selected>
                            __
                        </option>
                        @foreach ($conditions as $condition)
                            <option value="{{ $condition->id }}"
                                @if(isset($com))
                                    {{ $condition->id == $com->condition_id ? 'selected' : '' }}
                                @endif                                
                                >
                                {{ $condition->name }}
                            </option>
                        @endforeach
                    </select>
                    {{-- <input type="text" class="form-control" name="comments[condition][]"> --}}
                </div>
            </div>

            <div class="col-lg-4">
                <div class="form-group">
                    <label class="form-label" for="Values">{{ __('Values') }}</label>
                    <input type="text" 
                    @if(isset($com))
                        value="{{$com->values}}" 
                    @endif
                    class="form-control" name="comments[{{$loop->index}}][Values]">
                
                </div>
            </div>

            <div class="col-lg-4">
                <div class="form-group">
                    <label class="form-label"
                        for="Values">{{ __('Opration_Condition') }}</label>
                    <select class="form-control"  name="comments[{{$loop->index}}][Opration_Condition]">
                        <option class="text-center" selected>
                            __
                        </option>
                        <option 
                        value="or"

                        @if(isset($com))

                            {{ $com->operation_condition_type=='or' ? 'selected' : '' }}
                        @endif
                            >
                            {{ __('OR') }}
                        </option>
                        <option
                        value="and"

                        @if(isset($com))
                        {{ $com->operation_condition_type=='and' ? 'selected' : '' }}
                        @endif
                        >
                            {{ __('and') }}
                        </option>
                    </select>
                    {{-- <input type="text" class="form-control" name="Values[condition][]"> --}}
                </div>
            </div>


            <div class="col-lg-4">
                <div class="form-group">
                    <label class="form-label" 
                        for="Opration_Values">{{ __('Opration_Values') }}</label>
                    <select class="form-control" name="comments[{{$loop->index}}][Opration_Values]">
                        <option class="text-center" selected>
                            __
                        </option>

                        <option 
                        value="or"

                        @if(isset($com))
                        {{ $com->condition_values_type=='or' ? 'selected' : '' }}
                        @endif
                        >   
                            {{ __('OR') }}
                        </option>

                        <option
                        value="and"

                        @if(isset($com))
                        {{ $com->condition_values_type=='and' ? 'selected' : '' }}
                        @endif
                        >
                            {{ __('and') }}
                        </option>
                    </select>
                    {{-- <input type="text" class="form-control" name="Values[condition][]"> --}}
                </div>
            </div>

            <div class="col-lg-4">
                <div class="form-group">
                    <label class="form-label"
                        for="condition_Values">{{ __('condition_Values') }}</label>
                    <select class="form-control" name="comments[{{$loop->index}}][condition_Values]">
                        <option class="text-center" selected>
                            __
                        </option>
                        
                        <option
                         value="or"
                        @if(isset($com))
                        {{ $com->operation_values_type=='or' ? 'selected' : '' }}
                        @endif
                        >
                            {{ __('OR') }}
                        </option>

                        <option
                        value="and"

                        @if(isset($com))
                        {{ $com->operation_values_type=='and' ? 'selected' : '' }}
                        @endif
                        >
                            {{ __('and') }}
                        </option>
                    </select>
                    {{-- <input type="text" class="form-control" name="Values[condition][]"> --}}
                </div>
            </div>
            <div class="col-md-4">
        <button class="deleteCommentRow btn btn-danger mt-3" type="button">{{__('Delete')}}</button>
    </div>
        </div>
       
    </div>
    
    <hr class="my-3"/>
    
    @endforeach
    @else
    <div class="coment-row" data-row="0">
        <div class="row">
            <div class="col-lg-4 testSelect">
                <div class="form-group">
                    <label class="form-label" for="test">{{ __('Test Name') }}</label>
                    <select id="test" class="form-control" name="comments[0][test_id][]">
                        @foreach ($test->components as $component)
                            <option 
                            @if(isset($comment))
                                {{ $component->id == $comment->component_id ? 'selected' : '' }}
                            @endif
                            class="text-center" value="{{ $component->id }}">
                                {{ $component->name }}
                            </option>
                        @endforeach
                    </select>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="form-group">
                    <label class="form-label" for="operation">{{ __('Opertion Name') }}</label>
                    <select  class="opertionSelect form-control" name="comments[0][operations][id]">
                        <option class="text-center" selected>
                            __
                        </option>
                        @foreach ($operations as $operation)
                            <option data-operands="{{ $operation->operands }}" class="text-center"
                                value="{{ $operation->id }}"
                                @if(isset($comment))
                                    {{ $operation->id == $comment->operationComments->operation_id ? 'selected' : '' }}
                                @endif
                                >
                                {{ __($operation->name) }}
                            </option>
                        @endforeach
                    </select>
                </div>
            </div>


            @if(isset($com->operationComments))

            <div class="col-lg-4 values">
                <label value="" id="value_1">value_1</label>
                <input class="form-control" value="{{$comment->operationComments->value1}}" type="number" name="comments[0][operations][values][]">
            </div>

            @if($com->operationComments->value2!=null)
                <div class="col-lg-4 values">
                    <label value="" id="value_2">value_2</label>
                    <input class="form-control" value="{{$comment->operationComments->value2}}" type="number" name="comments[0][operations][values][]">
                </div>
            @endif

            @endif
            <div class="col-lg-4">
                <div class="form-group">
                    <label class="form-label" for="condition">{{ __('condition') }}</label>
                    <select class="form-control" name="comments[0][condition]">
                        <option class="text-center" selected>
                            __
                        </option>
                        @foreach ($conditions as $condition)
                            <option value="{{ $condition->id }}"
                                @if(isset($comment))
                                    {{ $condition->id == $comment->condition_id ? 'selected' : '' }}
                                @endif                                
                                >
                                {{ $condition->name }}
                            </option>
                        @endforeach
                    </select>
                    {{-- <input type="text" class="form-control" name="comments[condition][]"> --}}
                </div>
            </div>

            <div class="col-lg-4">
                <div class="form-group">
                    <label class="form-label" for="Values">{{ __('Values') }}</label>
                    <input type="text" 
                    @if(isset($comment))
                        value="{{$comment->values}}" 
                    @endif
                    class="form-control" name="comments[0][Values]">
                
                </div>
            </div>

            <div class="col-lg-4">
                <div class="form-group">
                    <label class="form-label"
                        for="Values">{{ __('Opration_Condition') }}</label>
                    <select class="form-control"  name="comments[0][Opration_Condition]">
                        <option class="text-center" selected>
                            __
                        </option>
                        <option 
                        value="or"

                        @if(isset($comment))

                            {{ $comment->operation_condition_type=='or' ? 'selected' : '' }}
                        @endif
                            >
                            {{ __('OR') }}
                        </option>
                        <option
                        value="and"

                        @if(isset($comment))
                        {{ $comment->operation_condition_type=='and' ? 'selected' : '' }}
                        @endif
                        >
                            {{ __('and') }}
                        </option>
                    </select>
                    {{-- <input type="text" class="form-control" name="Values[condition][]"> --}}
                </div>
            </div>


            <div class="col-lg-4">
                <div class="form-group">
                    <label class="form-label" 
                        for="Opration_Values">{{ __('Opration_Values') }}</label>
                    <select class="form-control" name="comments[0][Opration_Values]">
                        <option class="text-center" selected>
                            __
                        </option>

                        <option 
                        value="or"

                        @if(isset($comment))
                        {{ $comment->condition_values_type=='or' ? 'selected' : '' }}
                        @endif
                        >   
                            {{ __('OR') }}
                        </option>

                        <option
                        value="and"

                        @if(isset($comment))
                        {{ $comment->condition_values_type=='and' ? 'selected' : '' }}
                        @endif
                        >
                            {{ __('and') }}
                        </option>
                    </select>
                    {{-- <input type="text" class="form-control" name="Values[condition][]"> --}}
                </div>
            </div>

            <div class="col-lg-4">
                <div class="form-group">
                    <label class="form-label"
                        for="condition_Values">{{ __('condition_Values') }}</label>
                    <select class="form-control" name="comments[0][condition_Values]">
                        <option class="text-center" selected>
                            __
                        </option>
                        
                        <option
                         value="or"
                        @if(isset($comment))
                        {{ $comment->operation_values_type=='or' ? 'selected' : '' }}
                        @endif
                        >
                            {{ __('OR') }}
                        </option>

                        <option
                        value="and"

                        @if(isset($comment))
                        {{ $comment->operation_values_type=='and' ? 'selected' : '' }}
                        @endif
                        >
                            {{ __('and') }}
                        </option>
                    </select>
                    
                </div>
            </div>
            
           <div class="col-md-4">
        <button type="button" class="deleteCommentRow btn btn-danger mt-4">{{__('Delete')}}</button>
    </div>
        </div>
    </div>
    
    @endif
    
</div>
<div class="row">
    <div class="form-group">
        <label class="" for="comment">
            {{__('Comment')}}
        </label>
    </div>
    <textarea rows="" cols="" required name="comment" class="col-lg-12 form-control ray_comment"> @if(isset($comment[0]->comment)){{$comment[0]->comment->comment}}@endif</textarea>
</div>

<div class="row">
    <input type="button" class="d-flex justify-content-end btn btn-success" value="{{ __('add_auto_Comment') }}"
        id="add_comment">
</div>
