<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Controllers\Api\Response;
use App\Models\Notification;

class NotificationAPIController extends Controller
{
    // get all notification of user
    public function getAllNotificationOfUser()
    {
        $user = auth()->user();

        // get notification today
        $notifications = $user->notifications()->get();
        
        $data = [];

        foreach ($notifications as $key => $notification) {
            $data[] = [
                'id' => $notification->id,
                'content' => $notification->content,
                'report_id' => $notification->report_id,
                'image' =>$notification->image ? url('uploads/notifications-avatar/' . $notification->image) : null,
                'created_at' => $notification->created_at->format('Y-m-d'),
            ];
        }
        
        return Response::response(200, 'success', $data);
    } // end getAllNotificationOfUser

    // delete notification by id
    public function deleteNotificationOfUser($id)
    {
        $notification = Notification::find($id);

        if ($notification) {
            $notification->delete();
            return Response::response(200, __('Delete Notification Successfully'), []);
        } else {
            return Response::response(404, 'error', []);
        }
    } // end deleteNotificationById

    // delete all notification of user
    public function deleteAllNotificationOfUser()
    {
        $user = auth()->user();

        $user->notifications()->delete();

        return Response::response(200, __('Delete All Notifications Successfully'), []);
    } // end deleteAllNotificationOfUser


    // active notifit
    public function activeNotify()
    {

        $user = auth()->user();

        if ($user) {

            if ($user->is_notifiy == 0) {

                $user->update(['is_notifiy' => 1]);

                return Response::response(200, __('Enable Notification'), []);
            } else {

                $user->update(['is_notifiy' => 0]);

                return Response::response(200, __('Disable Notification'), []);
            } // end of else of user is notify

        } else {

            return Response::response(200, __('Not Found Token'), []);
        } // end of user

    } // end of active notification

}
