<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Test;
use App\Models\Culture;
use App\Models\Package;
use App\Http\Controllers\Api\Response;
use App\Models\ContractPrice;

class TestsLibraryController extends Controller
{
    public function testsPatient(Request $request)
    {
        $contract = auth()->user()->contract_id;



        $tests=Test::where(function($query){
            return $query->where('parent_id',0)->orWhere('separated',true);
        });



        //$tests = Test::whereHas('contract_prices',function($q)use($contract){return $q->where()})
        
        if($request->has('query'))
        {
           $tests->where('name','like','%'.$request['query'].'%');
        }

        $tests=$tests->get();

        if($contract != null){

            foreach($tests as $test){
                $price = ContractPrice::where('priceable_id',$test->id)->where('priceable_type','App\Models\Test')->where('contract_id',$contract)->first();
                if($price){
                    $test->price = $price->price;
                }
    
            }
        }

        return Response::response(200,'success',['tests'=>$tests]);
    }

    public function culturesPatient(Request $request)
    {
        $contract = auth()->user()->contract_id;

        $cultures=Culture::query();

        if($request->has('query'))
        {
            $cultures->where('name','like','%'.$request['query'].'%');
        }

        $cultures=$cultures->take(10)->get();

        if($contract != null){

            foreach($cultures as $test){
                $price = ContractPrice::where('priceable_id',$test->id)->where('priceable_type','App\Models\Culture')->where('contract_id',$contract)->first();
                if($price){
                    $test->price = $price->price;
                }
    
            }
        }

        return Response::response(200,'success',['cultures'=>$cultures]);
    }

    public function packagesPatient(Request $request)
    {
        $contract = auth()->user()->contract_id;

        $packages=Package::query();

        if($request->has('query'))
        {
            $packages->where('name','like','%'.$request['query'].'%');
        }

        $packages=$packages->take(10)->get();

        if($contract != null){

            foreach($packages as $test){
                $price = ContractPrice::where('priceable_id',$test->id)->where('priceable_type','App\Models\Package')->where('contract_id',$contract)->first();
                if($price){
                    $test->price = $price->price;
                }
    
            }
        }

        return Response::response(200,'success',['packages'=>$packages]);
    }
    public function testsLab(Request $request)
    {
        $contract = auth()->user()->lab_id;



        $tests=Test::where(function($query){
            return $query->where('parent_id',0)->orWhere('separated',true);
        });



        //$tests = Test::whereHas('contract_prices',function($q)use($contract){return $q->where()})
        
        if($request->has('query'))
        {
           $tests->where('name','like','%'.$request['query'].'%');
        }

        $tests=$tests->get();

        if($contract != null){

            foreach($tests as $test){
                $price = ContractPrice::where('priceable_id',$test->id)->where('priceable_type','App\Models\Test')->where('contract_id',$contract)->first();
                if($price){
                    $test->price = $price->price;
                }
    
            }
        }

        return Response::response(200,'success',['tests'=>$tests]);
    }

    public function culturesLab(Request $request)
    {
        $contract = auth()->user()->lab_id;

        $cultures=Culture::query();

        if($request->has('query'))
        {
            $cultures->where('name','like','%'.$request['query'].'%');
        }

        $cultures=$cultures->take(10)->get();

        if($contract != null){

            foreach($cultures as $test){
                $price = ContractPrice::where('priceable_id',$test->id)->where('priceable_type','App\Models\Culture')->where('contract_id',$contract)->first();
                if($price){
                    $test->price = $price->price;
                }
    
            }
        }

        return Response::response(200,'success',['cultures'=>$cultures]);
    }

    public function packagesLab(Request $request)
    {
        $contract = auth()->user()->lab_id;

        $packages=Package::query();

        if($request->has('query'))
        {
            $packages->where('name','like','%'.$request['query'].'%');
        }

        $packages=$packages->take(10)->get();

        if($contract != null){

            foreach($packages as $test){
                $price = ContractPrice::where('priceable_id',$test->id)->where('priceable_type','App\Models\Package')->where('contract_id',$contract)->first();
                if($price){
                    $test->price = $price->price;
                }
    
            }
        }

        return Response::response(200,'success',['packages'=>$packages]);
    }
}
