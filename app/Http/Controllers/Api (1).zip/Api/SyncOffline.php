<?php

namespace App\Http\Controllers\Api;

use App\Models\Test;
use App\Models\Group;
use App\Models\GroupTest;
use Illuminate\Support\Arr;
use App\Models\GroupCulture;
use Illuminate\Http\Request;
use App\Models\GroupTestResult;
use App\Models\GroupPayment;
use App\Http\Controllers\Controller;
use function GuzzleHttp\json_decode;
use App\Http\Controllers\Api\Response;
use App\Models\GroupCultureOption;
use App\Models\GroupCultureResult;
use PhpParser\ErrorHandler\Throwing;

class SyncOffline extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $invoice = json_decode($request['invoice'],true);
        $all_tests = json_decode($request['all_tests'],true);
        $all_tests_res = json_decode($request['all_tests_res'],true);
        
        $all_culture = json_decode($request['all_culture'],true);
        $culture_options = json_decode($request['culture_options'],true);
        $all_culture_res = json_decode($request['all_culture_res'],true);
        // $patient = json_decode($request['patient'],true);
        $payments = json_decode($request['payments'],true);
        
        
        




        $group = Group::create(Arr::except($invoice,'id'));
        $arr = [];



        try{
            foreach($all_tests as $test){
                $test['group_id'] = $group->id;
                $gorupTest = GroupTest::create(Arr::except($test,'id'));
                foreach($all_tests_res as $res){
                    if($res['group_test_id'] == $test['id']){
                        $res['group_test_id'] = $gorupTest['id'];
                      $hh = GroupTestResult::create(Arr::except($res,'id'));
                      $arr[] = $hh['id']; 
                    }
                };
            }
            
            foreach($all_culture as $test){
                $test['group_id'] = $group->id;
                $gorupCulture = GroupCulture::create(Arr::except($test,'id'));
                foreach($culture_options as $option){
                    if($option['group_culture_id'] == $test['id']){
                        $option['group_culture_id'] = $gorupCulture['id'];
                        GroupCultureOption::create(Arr::except($option,'id'));
                    }
                }
                foreach($all_culture_res as $res){
                    if($res['group_culture_id'] == $test['id']){
                        $res['group_culture_id'] = $gorupCulture['id'];
                        GroupCultureResult::create(Arr::except($res,'id'));
                    }
                }
                
    
            }
            
            
            foreach($payments as $pay){
                $pay['group_id'] = $group['id'];
                GroupPayment::create(Arr::except($pay,'id'));
            }
            
            
            $respons = [
                'done' => 200,
                'group' => $group->id,
                'arr' => $arr,
    
                ];
            return response()->json($respons);
        }catch(Throwing $e){
            $respons = [
                'done' => 400,
                'arr' => $e,
                ];
            return response()->json($respons);
        }

    }

}
