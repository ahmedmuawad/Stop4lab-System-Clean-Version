<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TestQuestion extends Model
{
    public $table="test_questions";
    public $guarded=[];

    

}
