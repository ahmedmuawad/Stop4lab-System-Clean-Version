<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SubContract extends Model
{
    public $table = "sub_contracts";
    public $guarded=[];
    
}
