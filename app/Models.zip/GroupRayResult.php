<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GroupRayResult extends Model
{
    public $guarded=[];
    public $table = 'group_ray_results';

}
