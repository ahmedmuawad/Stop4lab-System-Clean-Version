<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class invoiceImages extends Model
{
    public $guarded=[];

    
}
