<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Prefix extends Model
{
    public $table = 'prefixs';
    public $guarded=[];
}
