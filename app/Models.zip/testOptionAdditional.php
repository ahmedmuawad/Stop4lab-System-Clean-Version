<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class testOptionAdditional extends Model
{
    public $table = "test_option_additional";
    public $guarded=[];
}
