<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Labs_out extends Model
{
    public $table = 'labs_out';
    public $guarded=[];

}
